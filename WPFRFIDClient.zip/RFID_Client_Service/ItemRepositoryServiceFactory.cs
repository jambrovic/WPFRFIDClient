﻿using RFID_Client_Service.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace RFID_Client_Service
{
    public sealed class ItemRepositoryServiceFactory
    {
        private static readonly IRepositoryService<ItemService> _service = new ItemRepositoryService();

        private ItemRepositoryServiceFactory()
        {

        }

        public static IRepositoryService<ItemService> GetService()
        {
            return _service;
        }
    }
}
