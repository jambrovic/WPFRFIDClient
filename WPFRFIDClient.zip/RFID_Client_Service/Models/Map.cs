﻿using MongoDB.Bson;
using RFID_Client_Data.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace RFID_Client_Service.Models
{
    public sealed class Map
    {
        public static DALItem GetItem(ItemService itemViewModel)
        {
            return new DALItem
            {
                Barcode = itemViewModel.Barcode,
                Id = ObjectId.Parse(itemViewModel.Id),
                Name = itemViewModel.Name,
                RFIDCode = itemViewModel.RFIDCode,
                SecondaryCode = itemViewModel.SecondaryCode,
                UnitPrice = itemViewModel.UnitPrice
            };
        }

        public static ItemService GetItem(DALItem item)
        {
            return new ItemService
            {
                Barcode = item.Barcode,
                Id = item.Id.ToString(),
                Name = item.Name,
                RFIDCode = item.RFIDCode,
                SecondaryCode = item.SecondaryCode,
                UnitPrice = item.UnitPrice
            };
        }

        public static List<ItemService> GetItems(List<DALItem> items)
        {
            List<ItemService> itemCollection = new List<ItemService>();

            foreach (var i in items)
            {
                itemCollection.Add(GetItem(i));
            }

            return itemCollection;
        }

        public static List<DALItem> GetItems(List<ItemService> items)
        {
            List<DALItem> itemCollection = new List<DALItem>();

            foreach (var i in items)
            {
                itemCollection.Add(GetItem(i));
            }

            return itemCollection;
        }

        public static DALReceipt GetReceipt(ReceiptService receipt)
        {
            return new DALReceipt
            {
                DateCreated = receipt.DateCreated,
                DateFinished = receipt.DateFinished,
                Id = ObjectId.Parse(receipt.Id),
                Items = GetTransactions(receipt.Items),
                JIR = receipt.JIR,
                ZKI = receipt.ZKI,
                Total = receipt.Total,
                Payments = GetPayments(receipt.Payments)
            };
        }

        public static ReceiptService GetReceipt(DALReceipt receipt)
        {
            return new ReceiptService
            {
                DateCreated = receipt.DateCreated,
                DateFinished = receipt.DateFinished,
                Id = receipt.Id.ToString(),
                Items = GetTransactions(receipt.Items),
                JIR = receipt.JIR,
                ZKI = receipt.ZKI,
                Total = receipt.Total,
                Payments = GetPayments(receipt.Payments)
            };
        }

        public static List<DALReceiptTransaction> GetTransactions(List<TransactionService> transactions)
        {
            List<DALReceiptTransaction> transactionCollection = new List<DALReceiptTransaction>();

            foreach (var t in transactions)
            {
                transactionCollection.Add(new DALReceiptTransaction
                {
                    Barcode = t.Barcode,
                    DiscountPercent = t.DiscountPercent,
                    Id = ObjectId.Parse(t.Id),
                    Name = t.Name,
                    Quantity = t.Quantity,
                    RFIDCode = t.RFIDCode,
                    SecondaryCode = t.SecondaryCode,
                    UnitPrice = t.UnitPrice,
                    Timestamp = t.Timestamp
                });
            }
            return transactionCollection;
        }

        public static List<TransactionService> GetTransactions(List<DALReceiptTransaction> transactions)
        {
            List<TransactionService> transactionCollection = new List<TransactionService>();

            foreach (var t in transactions)
            {
                transactionCollection.Add(new TransactionService
                {
                    Barcode = t.Barcode,
                    DiscountPercent = t.DiscountPercent,
                    Id = t.Id.ToString(),
                    Name = t.Name,
                    Quantity = t.Quantity,
                    RFIDCode = t.RFIDCode,
                    SecondaryCode = t.SecondaryCode,
                    UnitPrice = t.UnitPrice,
                    Timestamp = t.Timestamp
                });
            }
            return transactionCollection;
        }

        public static List<DALPayment> GetPayments(List<PaymentService> payments)
        {
            List<DALPayment> paymentsCollection = new List<DALPayment>();

            foreach (var p in payments)
            {
                paymentsCollection.Add(new DALPayment
                {
                    Amount = p.Amount,
                    Code = p.Code,
                    Id = ObjectId.Parse(p.Id),
                    Name = p.Name
                });
            }
            return paymentsCollection;
        }

        public static List<PaymentService> GetPayments(List<DALPayment> payments)
        {
            List<PaymentService> paymentsCollection = new List<PaymentService>();

            foreach (var p in payments)
            {
                paymentsCollection.Add(new PaymentService
                {
                    Amount = p.Amount,
                    Code = p.Code,
                    Id = p.Id.ToString(),
                    Name = p.Name
                });
            }
            return paymentsCollection;
        }

        public static List<ReceiptService> GetReceipts(List<DALReceipt> receipts)
        {
            List<ReceiptService> receiptsCollection = new List<ReceiptService>();

            foreach (var r in receipts)
            {
                receiptsCollection.Add(GetReceipt(r));
            }

            return receiptsCollection;
        }

        public static List<DALReceipt> GetReceipts(List<ReceiptService> receipts)
        {
            List<DALReceipt> receiptsCollection = new List<DALReceipt>();

            foreach (var r in receipts)
            {
                receiptsCollection.Add(GetReceipt(r));
            }

            return receiptsCollection;
        }

        public static DALReceiptTransaction GetTransaction(TransactionService transaction)
        {
            return new DALReceiptTransaction
            {
                Barcode = transaction.Barcode,
                DiscountPercent = transaction.DiscountPercent,
                Id = ObjectId.Parse(transaction.Id),
                Name = transaction.Name,
                Quantity = transaction.Quantity,
                RFIDCode = transaction.RFIDCode,
                SecondaryCode = transaction.SecondaryCode,
                UnitPrice = transaction.UnitPrice,
                Timestamp = transaction.Timestamp
            };
        }

        public static TransactionService GetTransaction(DALReceiptTransaction transaction)
        {
            return new TransactionService
            {
                Barcode = transaction.Barcode,
                DiscountPercent = transaction.DiscountPercent,
                Id = transaction.Id.ToString(),
                Name = transaction.Name,
                Quantity = transaction.Quantity,
                RFIDCode = transaction.RFIDCode,
                SecondaryCode = transaction.SecondaryCode,
                UnitPrice = transaction.UnitPrice,
                Timestamp = transaction.Timestamp
            };
        }
    }
}
