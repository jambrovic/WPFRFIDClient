﻿using RFID_Client_Data;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace RFID_Client_Service.Models
{
    public class ItemRepositoryService : IRepositoryService<ItemService>
    {
        public async Task<long> Delete(string id)
        {
            return await ItemFactory.GetInstance().Delete(id);
        }

        public async Task Insert(ItemService entity)
        {
            await ItemFactory.GetInstance().Insert(Map.GetItem(entity));
        }

        public async Task<ItemService> Select(string id)
        {
            return Map.GetItem(await ItemFactory.GetInstance().Select(id));
        }

        public async Task<List<ItemService>> SelectAll()
        {
            return Map.GetItems(await ItemFactory.GetInstance().SelectAll());
        }

        public async Task<long> Update(ItemService entity)
        {
            return await ItemFactory.GetInstance().Update(Map.GetItem(entity));
        }
    }
}
