﻿using RFID_Client_Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RFID_Client_Service.Models
{
    public class ReceiptRepositoryService : IRepositoryService<ReceiptService>
    {
        public async Task<long> Delete(string id)
        {
            return await ReceiptFactory.GetInstance().Delete(id);
        }

        public async Task Insert(ReceiptService entity)
        {
            await ReceiptFactory.GetInstance().Insert(Map.GetReceipt(entity));
        }

        public async Task<ReceiptService> Select(string id)
        {
            return Map.GetReceipt(await ReceiptFactory.GetInstance().Select(id));
        }

        public async Task<List<ReceiptService>> SelectAll()
        {
            return Map.GetReceipts(await ReceiptFactory.GetInstance().SelectAll());
        }

        public async Task<long> Update(ReceiptService entity)
        {
            return await ReceiptFactory.GetInstance().Update(Map.GetReceipt(entity));
        }
    }
}
