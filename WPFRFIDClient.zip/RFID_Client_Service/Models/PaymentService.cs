﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RFID_Client_Service.Models
{
    public class PaymentService
    {
        public string Id { get; set; }

        public string Code { get; set; }

        public string Name { get; set; }

        public decimal Amount { get; set; }
    }
}
