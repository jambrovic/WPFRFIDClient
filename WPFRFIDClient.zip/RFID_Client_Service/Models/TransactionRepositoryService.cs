﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Bson;
using RFID_Client_Data;

namespace RFID_Client_Service.Models
{
    class TransactionRepositoryService : ITransactionService
    {
        public async Task<ReceiptService> Delete(TransactionService transaction, ObjectId receiptId)
        {
            return Map.GetReceipt(await TransactionFactory.GetInstance().Delete(Map.GetTransaction(transaction), receiptId));
        }

        public async Task<ReceiptService> Insert(TransactionService transaction, ObjectId receiptId)
        {
            return Map.GetReceipt(await TransactionFactory.GetInstance().Insert(Map.GetTransaction(transaction), receiptId));
        }

        public async Task<TransactionService> Select(TransactionService transaction, ObjectId receiptId)
        {
            return Map.GetTransaction(await TransactionFactory.GetInstance().Select(Map.GetTransaction(transaction), receiptId));
        }

        public async Task<List<TransactionService>> SelectAll(TransactionService transaction, ObjectId receiptId)
        {
            return Map.GetTransactions(await TransactionFactory.GetInstance().SelectAll(Map.GetTransaction(transaction), receiptId));
        }

        public async Task<long> Update(TransactionService transaction, ObjectId receiptId)
        {
            return await TransactionFactory.GetInstance().Update(Map.GetTransaction(transaction), receiptId);
        }
    }
}
