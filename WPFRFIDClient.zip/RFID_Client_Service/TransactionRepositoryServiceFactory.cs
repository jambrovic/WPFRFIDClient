﻿using RFID_Client_Service.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RFID_Client_Service
{
    public sealed class TransactionRepositoryServiceFactory
    {
        private static readonly ITransactionService _service = new TransactionRepositoryService();

        private TransactionRepositoryServiceFactory()
        {

        }

        public static ITransactionService GetService()
        {
            return _service;
        }
    }
}
