﻿using RFID_Client_Service.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RFID_Client_Service
{
    public sealed class ReceiptRepositoryServiceFactory
    {
        private static readonly IRepositoryService<ReceiptService> _service = new ReceiptRepositoryService();

        private ReceiptRepositoryServiceFactory()
        {

        }

        public static IRepositoryService<ReceiptService> GetService()
        {
            return _service;
        }
    }
}
