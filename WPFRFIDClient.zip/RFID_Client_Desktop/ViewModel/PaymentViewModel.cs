﻿using RFID_Client_Desktop.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RFID_Client_Desktop.ViewModel
{
    public class PaymentViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private ReceiptPayment receiptPayment;

        public PaymentViewModel(ReceiptPayment receiptPayment)
        {
            this.receiptPayment = receiptPayment;
        }

        public string Code
        {
            get
            {
                return receiptPayment.Code;
            }
            set
            {
                receiptPayment.Code = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Code"));
            }
        }

        public string Name
        {
            get
            {
                return receiptPayment.Name;
            }
            set
            {
                receiptPayment.Name = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Name"));
            }
        }

        public decimal Amount
        {
            get
            {
                return receiptPayment.Amount;
            }
            set
            {
                receiptPayment.Amount = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Amount"));
            }
        }
    }
}
