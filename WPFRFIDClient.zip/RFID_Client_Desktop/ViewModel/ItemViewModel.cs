﻿using MongoDB.Bson;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RFID_Client_Desktop.Models;

namespace RFID_Client_Desktop.ViewModel
{
    public class ItemViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private Item item;

        public ItemViewModel(Item item)
        {
            this.item = item;
        }


        public string Id
        {
            get
            {
                return item.Id;
            }
            set
            {
                item.Id = value.ToString();
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Id"));
            }
        }

        public string Barcode
        {
            get
            {
                return item.Barcode;
            }
            set
            {
                item.Barcode = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Barcode"));
            }
        }

        public string RFIDCode
        {
            get
            {
                return item.RFIDCode;
            }
            set
            {
                item.RFIDCode = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("RFIDCode"));
            }
        }

        public string Name
        {
            get
            {
                return item.Name;
            }
            set
            {
                item.Name = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Name"));
            }
        }

        public string SecondaryCode
        {
            get
            {
                return item.SecondaryCode;
            }
            set
            {
                item.SecondaryCode = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("SecondaryCode"));
            }
        }

        public decimal UnitPrice
        {
            get
            {
                return item.UnitPrice;
            }
            set
            {
                item.UnitPrice = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("UnitPrice"));
            }
        }
    }
}
