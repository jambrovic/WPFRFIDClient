﻿using RFID_Client_Desktop.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RFID_Client_Desktop.ViewModel
{
    public class TransactionViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private ReceiptTransaction receiptRow;
        
        public TransactionViewModel(ReceiptTransaction rr)
        {
            this.receiptRow = rr;
        }


        public int Ordinal
        {
            get
            {
                return receiptRow.Ordinal;
            }
            set
            {
                receiptRow.Ordinal = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Ordinal"));
            }
        }

        public string Barcode
        {
            get
            {
                return receiptRow.Barcode;
            }
            set
            {
                receiptRow.Barcode = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Barcode"));
            }
        }

        public string Name
        {
            get
            {
                return receiptRow.Name;
            }
            set
            {
                receiptRow.Name = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Name"));
            }
        }

        public decimal Quantity
        {
            get
            {
                return receiptRow.Quantity;
            }
            set
            {
                receiptRow.Quantity = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Quantity"));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Total"));
            }
        }

        public decimal UnitPrice
        {
            get
            {
                return receiptRow.UnitPrice;
            }
            set
            {
                receiptRow.UnitPrice = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("UnitPrice"));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Total"));
            }
        }

        public decimal DiscountPercent
        {
            get
            {
                return receiptRow.DiscountPercent;
            }
            set
            {
                receiptRow.DiscountPercent = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("DiscountPercent"));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Total"));
            }
        }

        public decimal Total
        {
            get
            {
                return receiptRow.Total;
            }
        }
    }
}
