﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using RFID_Client_Desktop.Models;
using System.Windows;
using RFID_Client_Service;
using RFID_Client_Desktop.Utils;

namespace RFID_Client_Desktop.ViewModel
{
    public class ReceiptViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private Models.Receipt receipt;
        private ObservableCollection<TransactionViewModel> itemsObservable;

        public ReceiptViewModel(Models.Receipt receipt)
        {
            this.receipt = receipt;

            this.receipt.Id = ObjectIdFactory.GetObjectIdString();
            this.receipt.Payments = new List<ReceiptPayment>();

            itemsObservable = new ObservableCollection<TransactionViewModel>();
            itemsObservable.CollectionChanged += _items_CollectionChanged;
            Refresh();
        }

        private void _items_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            Refresh();
        }

        public decimal Total
        {
            get
            {
                return receipt.Total;
            }
            set
            {
                receipt.Total = value;
                Refresh();
            }
        }

        public ObservableCollection<TransactionViewModel> Items
        {
            get
            {
                return itemsObservable;
            }
            set
            {
                itemsObservable = value;
                receipt.Items = GetTransactions(value);
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Total"));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("QuantityTotal"));
            }
        }

        public void AddItem(ReceiptTransaction rr)
        {

            if (!ItemExists(rr))
            {
                itemsObservable.Add(new TransactionViewModel(rr));
            }

            if (receipt.Items == null)
            {
                receipt.Items = new List<ReceiptTransaction>();
            }

            if (!receipt.Items.Exists(i => i.Barcode.Equals(rr.Barcode)))
            {
                receipt.Items.Add(rr);
            }

            Refresh();
        }

        public decimal QuantityTotal
        {
            get
            {
                return receipt.QuantityTotal;
            }
        }

        public decimal RestForPayment
        {
            get
            {
                return receipt.Total - receipt.Payments.Sum(p => p.Amount);
            }
        }

        public List<ReceiptPayment> Payments
        {
            get
            {
                return receipt.Payments;
            }
            set
            {
                receipt.Payments = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Payments"));
            }
        }

        public List<ReceiptTransaction> GetTransactions(ObservableCollection<TransactionViewModel> rrVM)
        {
            var col = new List<ReceiptTransaction>();
            foreach (TransactionViewModel item in rrVM)
            {
                col.Add(new ReceiptTransaction
                {
                    Barcode = item.Barcode,
                    DiscountPercent = item.DiscountPercent,
                    Name = item.Name,
                    Quantity = item.Quantity,
                    UnitPrice = item.UnitPrice,
                    
                });
            }

            return col;
        }

        public void Refresh()
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Total"));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("QuantityTotal"));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Payments"));
        }

        private bool ItemExists(ReceiptTransaction rr)
        {
            foreach (TransactionViewModel row in itemsObservable)
            {
                if (row.Barcode.Equals(rr.Barcode))
                {
                    return true;
                }
            }
            return false;
        }

        internal async void FinishReceipt()
        {
            try
            {
                this.receipt.DateFinished = DateTime.Now.ToLocalTime();
                await ReceiptRepositoryServiceFactory.GetService().Insert(Map.GetReceipt(this.receipt));

                Items.Clear();

                this.receipt.Payments.Clear();
                this.receipt = new Models.Receipt();

                Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,"Receipt Finish",MessageBoxButton.OK,MessageBoxImage.Error);
            }

        }

        public Models.Receipt GetReceipt()
        {
            return this.receipt;
        }
    }
}
