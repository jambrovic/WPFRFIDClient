﻿using RFID_Client_Desktop.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RFID_Client_Desktop.ItemForms
{
    /// <summary>
    /// Interaction logic for ItemDataGrid.xaml
    /// </summary>
    public partial class ItemDataGrid : Window
    {
        private IEnumerable<Item> _items;
        public ItemDataGrid(IEnumerable<Item> items)
        {
            InitializeComponent();
            _items = items;
        }

        private ItemDataGrid()
        {

        }

        private void dGridItems_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {

        }
        
    }
}
