﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RFID_Client_Desktop.Models
{
    public enum PaymentType
    {
        CASH,
        CREDIT_CARD,
        AMERICAN_EXPRESS,
        VISA,
        VISA_ELECTRON,
        MASTERCARD,
        MAESTRO,
        DINERS,
        CEK,
        OSTALO
    }
}
