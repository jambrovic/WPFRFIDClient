﻿using RFID_Client_Arduino;
using RFID_Client_Desktop.ItemForms;
using RFID_Client_Desktop.Models;
using RFID_Client_Desktop.PaymentForms;
using RFID_Client_Desktop.Utils;
using RFID_Client_Desktop.ViewModel;
using RFID_Client_Helpers;
using RFID_Client_Service;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RFID_Client_Desktop
{
    /// <summary>
    /// Interaction logic for Receipt.xaml
    /// </summary>
    public partial class Receipt : Window
    {
        private ReceiptViewModel receiptVM;
        private string buffer = "";
        private IReader _readerInstance;
        private string _receiveBuffer;
        private bool _isReceiveComplete = false;
        private bool _isItemInsertWindowOpened = false;
        private HashSet<string> _receiptScannedItemsBuffer;
        private bool isRFIDReaderConnected = false;

        private int _receiptTransactionOrdinal = 1;


        public Receipt()
        {
            InitializeComponent();
            _receiptScannedItemsBuffer = new HashSet<string>();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            StartReader();
            StartReaderConnectionMonitor();

            receiptVM = new ReceiptViewModel(new Models.Receipt());

            try
            {
                DataContext = receiptVM;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void StartReaderConnectionMonitor()
        {
            Thread checkReaderConnectionThread = new Thread(() =>
            {
                while (true)
                {
                    if (_readerInstance != null && !_readerInstance.IsConnected())
                    {
                        isRFIDReaderConnected = false;
                        _readerInstance.StopReading();
                        _readerInstance.onReaderDataReceived -= _readerInstance_onReaderDataReceived;
                        _readerInstance = null;
                    }
                    Thread.Sleep(1000);
                }

            })
            {
                IsBackground = true,
                Name = "checkReaderConnectionThread"
            };
            checkReaderConnectionThread.Start();
        }

        private void StartReader()
        {
            Thread readerThread = new Thread(() =>
            {
                while (true)
                {
                    if (!isRFIDReaderConnected)
                    {
                        try
                        {
                            ReaderFactory.SetPortConfig("COM7", 9600, true);
                            _readerInstance = ReaderFactory.GetRFIDReader();
                            _readerInstance.StartReading();
                            _receiveBuffer = String.Empty;
                            _readerInstance.onReaderDataReceived += _readerInstance_onReaderDataReceived;
                            isRFIDReaderConnected = true;
                        }
                        catch (Exception)
                        {
                            isRFIDReaderConnected = false;
                            if (_readerInstance != null)
                            {
                                _readerInstance.StopReading();
                                _readerInstance.onReaderDataReceived -= _readerInstance_onReaderDataReceived;
                            }
                            _readerInstance = null;
                        }
                    }
                    Thread.Sleep(1000);
                }
            })
            {
                IsBackground = true,
                Name = "readerThread"
            };
            readerThread.Start();
        }

        private void _readerInstance_onReaderDataReceived(string data)
        {
            Thread t = new Thread(() =>
              {
                  _receiveBuffer += data;
                  _isReceiveComplete = (_receiveBuffer[_receiveBuffer.Length - 1] == '\n');

                  if (_isReceiveComplete)
                  {
                      string rfid = _receiveBuffer;
                      rfid = rfid.Replace(Environment.NewLine, "");
                      _receiveBuffer = "";
                      _isReceiveComplete = false;

                      App.Current.Dispatcher.Invoke(async () =>
                      {
                          await InsertReceiptItem(rfid);
                      });
                  }
              });

            t.Start();
        }

        private async Task InsertReceiptItem(string rfid)
        {
            try
            {
                if (!_receiptScannedItemsBuffer.Contains(rfid))
                {
                    _receiptScannedItemsBuffer.Add(rfid);
                    Item queriedItem;

                    using (new WaitCursor())
                    {
                        queriedItem = Map.GetItem(await ItemRepositoryServiceFactory.GetService().Select(rfid));
                    }

                    if (queriedItem != null)
                    {
                        ReceiptTransaction rr = new ReceiptTransaction
                        {
                            Ordinal = _receiptTransactionOrdinal,
                            Barcode = queriedItem.Barcode,
                            Name = queriedItem.Name,
                            SecondaryCode = queriedItem.SecondaryCode,
                            RFIDCode = queriedItem.RFIDCode,
                            Quantity = 1,
                            UnitPrice = queriedItem.UnitPrice,
                            Id = ObjectIdFactory.GetObjectIdString(),
                            Timestamp=DateTime.Now.ToLocalTime()
                        };
                        receiptVM.AddItem(rr);
                        _receiptTransactionOrdinal++;
                    }
                    else
                    {
                        throw new Exception(String.Format("Item with RFID {0} does not exists!", rfid));
                    }

                }
            }
            catch (InvalidOperationException)
            {
                MessageBox.Show(String.Format("Item not found.{0}Please insert the item into the system!{1}RFID code: {2}", Environment.NewLine, Environment.NewLine, rfid), "Warning", MessageBoxButton.YesNo, MessageBoxImage.Question);

                //Remove the item from buffer so it can be scanned again
                _receiptScannedItemsBuffer.Remove(rfid);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ClientException.GetFormatedException(ex), rfid);
            }
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.Key >= Key.D0 && e.Key <= Key.D9) || (e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9))
            {
                foreach (char c in e.Key.ToString())
                {
                    if (char.IsDigit(c))
                    {
                        buffer += c;
                    }
                }
            }

            if (e.Key == Key.Enter)
            {
                MessageBox.Show(buffer);
                buffer = "";
            }
            else if (e.Key == Key.Add || e.Key == Key.OemPlus)
            {
                {
                    AddNewItem();
                }
            }
            else if (e.Key == Key.A)
            {
                if (spReceiptRows.SelectedIndex >= 0)
                {
                    (spReceiptRows.SelectedItem as TransactionViewModel).Quantity++;
                    receiptVM.Refresh();
                }
            }
        }

        private void AddNewItem()
        {
            try
            {
                ReceiptTransaction rr = new ReceiptTransaction
                {
                    Ordinal = _receiptTransactionOrdinal,
                    Barcode = "33333333333",
                    Name = "Item c",
                    SecondaryCode = "C_333",
                    RFIDCode = "12345678912",
                    Quantity = 3,
                    UnitPrice = 36.56M,
                    Id = ObjectIdFactory.GetObjectIdString()
                };
                //r.Items.Add(rr);
                receiptVM.AddItem(rr);
                _receiptTransactionOrdinal++;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ClientException.GetFormatedException(ex), "Error");
            }

        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            try
            {
                if (_readerInstance != null)
                {
                    _readerInstance.onReaderDataReceived -= _readerInstance_onReaderDataReceived;
                    _readerInstance.StopReading();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
        }

        private void mnuExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void mnuReceiptNew_Click(object sender, RoutedEventArgs e)
        {

        }

        private void mnuItemsNew_Click(object sender, RoutedEventArgs e)
        {
            if (!_isItemInsertWindowOpened)
            {
                ItemInsert itemInsertWindow = new ItemInsert();
                _isItemInsertWindowOpened = true;
                itemInsertWindow.Owner = this;
                itemInsertWindow.Show();
            }
        }

        private void mnuOptionsConfiguration_Click(object sender, RoutedEventArgs e)
        {

        }

        private void mnuHelpAbout_Click(object sender, RoutedEventArgs e)
        {

        }

        private async void mnuItemsAll_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                ItemDataGrid itemDataGrid;

                using (new WaitCursor())
                {
                    var items = await ItemRepositoryServiceFactory.GetService().SelectAll();
                    itemDataGrid = new ItemDataGrid(Map.GetItems(items));
                    itemDataGrid.dGridItems.ItemsSource = items;
                };

                itemDataGrid.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Items", MessageBoxButton.OK);

            }
        }

        private void btnCheckout_Click(object sender, RoutedEventArgs e)
        {
            if (receiptVM.QuantityTotal > 0)
            {
                PaymentWindow paymentWindow = new PaymentWindow(receiptVM);
                paymentWindow.ShowDialog();
                _receiveBuffer = String.Empty;
                _receiptScannedItemsBuffer = new HashSet<string>();
                _receiptTransactionOrdinal = 1;
            }
        }
    }
}
