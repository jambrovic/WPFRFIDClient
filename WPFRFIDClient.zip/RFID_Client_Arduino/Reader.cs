﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RFID_Client_Arduino
{
    class Reader : IReader
    {
        private SerialPort _serialPort;
        private string _port;
        private int _baud;
        private bool _dtrEnable;

        public event RFID_Client_Arduino.ReaderEventHandler onReaderDataReceived;

        public Reader(string portName, int baudRate, bool dtrEnable)
        {
            _serialPort = new SerialPort();
            _serialPort.PortName = portName;
            _serialPort.BaudRate = baudRate;
            _serialPort.DtrEnable = dtrEnable;

            _port = portName;
            _baud = baudRate;
            _dtrEnable = dtrEnable;

            _serialPort.DataReceived += _serialPort_DataReceived;
        }

        public void _serialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            this.onReaderDataReceived.Invoke(_serialPort.ReadExisting());
        }

        public void StartReading()
        {
            PortOpen();
        }

        public void StopReading()
        {
            PortClose();
        }

        public IReader GetReader(string portName, int baudRate, bool dtrEnable)
        {
            return new Reader(portName, baudRate, dtrEnable);
        }

        private bool PortOpen()
        {
            try
            {
                if (!_serialPort.IsOpen)
                {
                    _serialPort.Open();
                }

                return true;
            }
            catch (Exception)
            {
                throw;
            }
        }

        private bool PortClose()
        {
            try
            {
                if (_serialPort.IsOpen)
                {
                    _serialPort.Close();
                    _serialPort.DataReceived -= _serialPort_DataReceived;
                }

                return true;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public bool IsConnected()
        {
            return _serialPort.IsOpen;
        }

    }
}
