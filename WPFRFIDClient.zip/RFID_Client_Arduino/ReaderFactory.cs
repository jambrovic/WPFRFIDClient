﻿namespace RFID_Client_Arduino
{
    public sealed class ReaderFactory
    {
        private static IReader _instance;
        
        private ReaderFactory() { }

        public static void SetPortConfig(string portName, int baudRate, bool dtrEnable)
        {
            if (_instance == null)
            {
                _instance = new Reader(portName, baudRate, dtrEnable);
            }
        }

        public static IReader GetRFIDReader()
        {
            return _instance;
        }

        

    }
}
