﻿using RFID_Client_Data.DAL;
using RFID_Client_Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RFID_Client_Data
{
    public sealed class TransactionFactory
    {
        private static readonly ITransaction _instance = new TransactionRepository();

        private TransactionFactory()
        {

        }

        public static ITransaction GetInstance()
        {
            return _instance;
        }
    }
}
