﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RFID_Client_Data.DB
{
    public sealed class DBConfiguration
    {
        private static readonly string _dbName = "Receipts";
        private static readonly string _receiptsCollection="Y2017";
        private static readonly string _itemsCollection="Items";
        private static readonly string _connectionString= "mongodb://localhost:27017";
        private DBConfiguration()
        {

        }

        public static string GetReceiptsCollection()
        {
            return _receiptsCollection;
        }

        public static string GetItemsCollection()
        {
            return _itemsCollection;
        }

        public static string GetConnectionString()
        {
            return _connectionString;
        }

        public static string GetDatabaseName()
        {
            return _dbName;
        }
    }
}
