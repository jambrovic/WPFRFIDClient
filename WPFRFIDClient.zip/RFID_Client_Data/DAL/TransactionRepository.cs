﻿using MongoDB.Bson;
using MongoDB.Driver;
using RFID_Client_Data.DB;
using RFID_Client_Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RFID_Client_Data.DAL
{
    public class TransactionRepository : ITransaction
    {
        private readonly IMongoDatabase _db;
        private readonly IMongoCollection<DALReceipt> _receiptsCollection;
        private readonly IMongoCollection<DALItem> _itemsCollection;
        private readonly MongoClient _client;

        public TransactionRepository()
        {
            _client = new MongoClient(DBConfiguration.GetConnectionString());
            _db = _client.GetDatabase(DBConfiguration.GetDatabaseName());
            _receiptsCollection = _db.GetCollection<DALReceipt>(DBConfiguration.GetReceiptsCollection());
            _itemsCollection = _db.GetCollection<DALItem>(DBConfiguration.GetItemsCollection());
        }

        public async Task<DALReceipt> Delete(DALReceiptTransaction transaction, ObjectId receiptId)
        {
            var filter = Builders<DALReceipt>.Filter.Eq("_id", receiptId);
            var update = Builders<DALReceipt>.Update.PullFilter(r => r.Items, i => i.RFIDCode == transaction.RFIDCode);
            var options = new FindOneAndUpdateOptions<DALReceipt>
            {
                ReturnDocument = ReturnDocument.After
            };

            return await _receiptsCollection.FindOneAndUpdateAsync(filter, update, options);
        }

        public async Task<DALReceipt> Insert(DALReceiptTransaction transaction, ObjectId receiptId)
        {
            var filter = Builders<DALReceipt>.Filter.Eq("_id", receiptId);
            var update = Builders<DALReceipt>.Update.Push(r => r.Items, transaction);
            var options = new FindOneAndUpdateOptions<DALReceipt>
            {
                ReturnDocument = ReturnDocument.After
            };

            return await _receiptsCollection.FindOneAndUpdateAsync(filter, update, options);
        }

        public async Task<List<DALReceiptTransaction>> SelectAll(DALReceiptTransaction transaction, ObjectId receiptId)
        {
            DALReceipt receipt = await _receiptsCollection.Find(Builders<DALReceipt>.Filter.Where(r => r.Id.Equals(receiptId))).SingleAsync();
            return receipt.Items;
        }

        public async Task<DALReceiptTransaction> Select(DALReceiptTransaction transaction, ObjectId receiptId)
        {
            DALReceipt receipt = await _receiptsCollection.Find(Builders<DALReceipt>.Filter.Where(r => r.Id.Equals(receiptId))).SingleAsync();
            return receipt.Items.Where(r => r.RFIDCode == transaction.RFIDCode).FirstOrDefault();
        }

        public Task<long> Update(DALReceiptTransaction transaction, ObjectId receiptId)
        {
            throw new NotImplementedException();
        }
    }
}
