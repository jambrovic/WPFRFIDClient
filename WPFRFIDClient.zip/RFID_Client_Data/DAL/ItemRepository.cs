﻿using MongoDB.Bson;
using MongoDB.Driver;
using RFID_Client_Data.Models;
using RFID_Client_Data.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RFID_Client_Data.DAL
{
    class ItemRepository : IRepository<DALItem>
    {
        private readonly IMongoDatabase _db;
        private readonly IMongoCollection<BsonDocument> _receiptsCollection;
        private readonly IMongoCollection<DALItem> _itemsCollection;
        private readonly MongoClient _client;

        public ItemRepository()
        {
            try
            {
                _client = new MongoClient(DBConfiguration.GetConnectionString());
                _db = _client.GetDatabase(DBConfiguration.GetDatabaseName());
                _receiptsCollection = _db.GetCollection<BsonDocument>(DBConfiguration.GetReceiptsCollection());
                _itemsCollection = _db.GetCollection<DALItem>(DBConfiguration.GetItemsCollection());
            }
            catch (Exception)
            {
                throw;
            }
        }
        public async Task<DALItem> Select(string rfid)
        {
            try
            {
                var builder = Builders<DALItem>.Filter;
                var filter = builder.Eq("rfidCode", rfid);
                return await _itemsCollection.Find(filter).SingleAsync();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task Insert(DALItem item)
        {
            try
            {
                #region Delete item if exists

                var builder = Builders<DALItem>.Filter;
                var filter = builder.Eq("rfidCode", item.RFIDCode);
                DeleteResult deleteResult = await _itemsCollection.DeleteManyAsync(filter);

                #endregion

                await _itemsCollection.InsertOneAsync(item);
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Deletes item by rfid code
        /// </summary>
        /// <param name="rfid"></param>
        /// <returns>Count of deleted documents</returns>
        public async Task<long> Delete(string rfid)
        {
            try
            {
                var builder = Builders<DALItem>.Filter;
                var filter = builder.Eq("rfidCode", rfid);
                DeleteResult result = await _itemsCollection.DeleteManyAsync(filter);
                return result.DeletedCount;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public async Task<long> Update(DALItem newItem)
        {
            try
            {
                DALItem itemForUpdate = await Select(newItem.RFIDCode);

                var builder = Builders<DALItem>.Filter;
                var filter = builder.Eq("_id", itemForUpdate.Id);
                var update = Builders<DALItem>.Update
                    .Set("barcode", newItem.Barcode)
                    .Set("name", newItem.Name)
                    .Set("secondaryCode", newItem.SecondaryCode)
                    .Set("unitPrice", newItem.UnitPrice);

                UpdateResult result = await _itemsCollection.UpdateOneAsync(filter,update);

                return result.ModifiedCount;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public async Task<List<DALItem>> SelectAll()
        {
            return await _itemsCollection.Find(Builders<DALItem>.Filter.Empty).ToListAsync();
        }
    }
}
