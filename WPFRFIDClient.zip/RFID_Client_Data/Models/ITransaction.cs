﻿using MongoDB.Bson;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RFID_Client_Data.Models
{
    public interface ITransaction
    {
        Task<DALReceipt> Insert(DALReceiptTransaction transaction, ObjectId receiptId);
        Task<DALReceiptTransaction> Select(DALReceiptTransaction transaction, ObjectId receiptId);
        Task<List<DALReceiptTransaction>> SelectAll(DALReceiptTransaction transaction, ObjectId receiptId);
        Task<DALReceipt> Delete(DALReceiptTransaction transaction, ObjectId receiptId);
        Task<long> Update(DALReceiptTransaction transaction, ObjectId receiptId);
    }
}
