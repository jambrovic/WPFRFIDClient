﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RFID_Client_Data.Models
{
    public interface IRepository<T> where T : class
    {
        Task Insert(T entity);
        Task<T> Select(string id);
        Task<List<T>> SelectAll();
        Task<long> Update(T entity);
        Task<long> Delete(string id);

    }
}
