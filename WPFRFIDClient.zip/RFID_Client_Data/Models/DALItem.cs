﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson.Serialization.IdGenerators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RFID_Client_Data.Models
{
    public class DALItem
    {
        [BsonId(IdGenerator = typeof(ObjectIdGenerator))]
        public ObjectId Id { get; set; }

        [BsonElement("barcode")]
        public string Barcode { get; set; }

        [BsonElement("rfidCode")]
        public string RFIDCode { get; set; }

        [BsonElement("secondaryCode")]
        public string SecondaryCode { get; set; }

        [BsonElement("name")]
        public string Name { get; set; }

        [BsonElement("unitPrice")]
        public decimal UnitPrice { get; set; }

    }
}
