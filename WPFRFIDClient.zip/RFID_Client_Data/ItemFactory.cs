﻿using RFID_Client_Data.DAL;
using RFID_Client_Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RFID_Client_Data
{
    public sealed class ItemFactory
    {
        private static readonly IRepository<DALItem> _instance = new ItemRepository();
        private ItemFactory()
        {

        }

        public static IRepository<DALItem> GetInstance()
        {
            return _instance;
        }
    }
}
